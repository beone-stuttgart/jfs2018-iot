#pragma once

enum class HomieBootMode : uint8_t {
  UNDEFINED = 0,
  STANDALONE = 1,
  CONFIGURATION = 2,
  NORMAL = 3
};
